﻿using System;

namespace Bugs
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //https://nl.wikipedia.org/wiki/Vierkantsvergelijking 
            //Test waarden: a=1,b=0,c=-1    => D= 4, X=-1,X=1
            //a=1,b=4,c=-5                  => D= 36, X=1, X=-5
            Console.WriteLine("Geef a");
            string inpa = Console.ReadLine();
            Console.WriteLine("Geef b");
            string inpb = Console.ReadLine();
            Console.WriteLine("Geef c");
            string inpc = Console.ReadLine();
            int a = Convert.ToInt32(inpa);
            int b = Convert.ToInt32(inpb);
            int c = Convert.ToInt32(inpb);

            Console.WriteLine($"Ingevoerde vergelijking {inpa}X²+{inpb}X+{inpc}");
            double D = b*b - 4 * a * c;
            Console.WriteLine($"D={D}");

            if(D<0)
            {
                Console.WriteLine("Geen oplossingen mogelijk daar D 0 is");
            }
            else if(D>0)
            {
                double x1 = (-b + Math.Sqrt(D)) / 2 * a;
                double x2= -(-b + Math.Sqrt(D)) / 2 * a;
                Console.WriteLine($"X1={x1}, X2={x2}");
            }
            else
            {
                Console.WriteLine("Twee complexe getallen zijn de oplossing, maar de programmeur was te lui");
                Console.WriteLine("Kan jij het nog oplossen?");
            }




        }
    }
}
